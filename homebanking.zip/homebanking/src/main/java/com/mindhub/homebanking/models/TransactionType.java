package com.mindhub.homebanking.models;


public enum TransactionType {
    CREDIT,
    DEBIT,

}
